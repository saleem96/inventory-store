@extends('master')

@section('content')

    <div class="m-grid__item m-grid__item--fluid m-wrapper">
        <!-- BEGIN: Subheader -->
        <div class="m-subheader ">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="m-subheader__title ">
                        Dashboard
                    </h3>
                </div>



            </div>
        </div>
        <!-- END: Subheader -->
        <div class="m-content">
                        <div class="row">
                            <div class="col-xl-6">
								<!--begin:: Widgets/Activity-->

		                    </div>




                        </div>
        </div>
    </div>
@endsection
