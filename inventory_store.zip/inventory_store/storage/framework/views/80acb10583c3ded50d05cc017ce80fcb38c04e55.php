<?php $__env->startSection('script'); ?>
    <script>
        $( document ).ready(function() {
            $('#state').on('change', function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                var state_id  = this.value;
                $.ajax({

                    url: '/sku/check/'+state_id ,

                    type: 'POST',

                    data : {'stateID' : state_id},
                    dataType: 'json',

                success:function(response) {

                    if(response==false)
                    {

                        $( "#c_stock" ).prop( "disabled", true );
                    }
                }
            });
              });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php if($errors->has('image')): ?>
    <?php endif; ?>
</div>
<?php endif; ?>

    <div class="m-content">
        <div class="row">
            <div class="col-lg-12">
                <div class="m-portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <span class="m-portlet__head-icon m--hide">
                                    <i class="la la-gear"></i>
                                </span>
                                <h3 class="m-portlet__head-text">
                                    Add Shipment
                                </h3>
                            </div>
                        </div>
                    </div>
                    <form  method="post" action="<?php echo e(route('add.shipment')); ?>" class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
                        <?php echo e(csrf_field()); ?>

                        <div class="m-portlet__body">
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    SKU:
                                </label>
                                <div class="col-lg-3">
                                <select class="form-control m-input" name="product_id" id="state">
									<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->sku); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


								</select>
                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Quantity:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" class="form-control m-input" name="quantity" placeholder="please enter">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Unit Price:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="unit_price" class="form-control m-input" placeholder="please enter">

                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Shipping:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="shipping" class="form-control m-input" placeholder="please enter">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Total:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="total" class="form-control m-input" placeholder="please enter">

                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Arrived final
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="arrived_final" class="form-control m-input" placeholder="please enter">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    paid:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="paid" class="form-control m-input" placeholder="please enter">

                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Payment method:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="payment_method" class="form-control m-input" placeholder="please enter">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Supplier:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="supplier" class="form-control m-input" placeholder="please enter">

                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Date Paid:
                                </label>
                                <div class="col-lg-3">
                                    <input class="form-control m-input" name="date_paid" type="date" value="2011-08-19" id="example-date-input">
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    status:
                                </label>
                                <div class="col-lg-3">
                                    <div class="m-radio-inline">
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="status" checked="" value="Shipped">
                                            Shipped
                                            <span></span>
                                        </label>
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="status" value="Not shipped">
                                            Not shipped
                                            <span></span>
                                        </label>
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="status" value="arrived">
                                            Arrived
                                            <span></span>
                                        </label>
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="status" value="done">
                                            Done
                                            <span></span>
                                        </label>
                                    </div>
                                    <span class="m-form__help">
                                        Please select
                                    </span>
                                </div>
                                <label class="col-lg-2 col-form-label">
                                    Ship Date:
                                </label>
                                <div class="col-lg-3">
                                    <input class="form-control m-input" name="ship_date" type="date" value="2011-08-19" id="example-date-input">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Carrier:
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="carrier" class="form-control m-input" placeholder="please enter">

                                </div>
                                <label class="col-lg-2 col-form-label">
                                    tracking#
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" name="tracking_number" class="form-control m-input" placeholder="please enter">

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Current Stock
                                </label>
                                <div class="col-lg-3">
                                    <input type="text" id="c_stock" name="current_stock" class="form-control m-input" placeholder="please enter">

                                </div>

                            </div>

                            <div class="form-group m-form__group row">
                                <label class="col-lg-2 col-form-label">
                                    Docs
                                </label>
                                <div class="col-lg-3">
                                    <div class="m-radio-inline">
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="docs" checked="" value="1">
                                            yes
                                            <span></span>
                                        </label>
                                        <label class="m-radio m-radio--solid">
                                            <input type="radio" name="docs" value="0">
                                            no
                                            <span></span>
                                        </label>
                                    </div>
                                    <span class="m-form__help">
                                        Please select
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
                            <div class="m-form__actions m-form__actions--solid">
                                <div class="row">
                                    <div class="col-lg-2"></div>
                                    <div class="col-lg-10">
                                        <button type="submit" class="btn btn-success">
                                            Submit
                                        </button>
                                        <a class="btn btn-secondary" href="/shipment/index">

                                            Cancel

                                    </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\office\inventory_store\resources\views/shipment/create.blade.php ENDPATH**/ ?>