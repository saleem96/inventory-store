<?php $__env->startSection('content'); ?>

    <div class="m-grid__item m-grid__item--fluid m-wrapper">
        <!-- BEGIN: Subheader -->
        <div class="m-subheader ">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="m-subheader__title ">
                        Dashboard
                    </h3>
                </div>



            </div>
        </div>
        <!-- END: Subheader -->
        <div class="m-content">
                        <div class="row">
                            <div class="col-xl-6">
								<!--begin:: Widgets/Activity-->

		                    </div>




                        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\office\inventory_store\resources\views/welcome.blade.php ENDPATH**/ ?>