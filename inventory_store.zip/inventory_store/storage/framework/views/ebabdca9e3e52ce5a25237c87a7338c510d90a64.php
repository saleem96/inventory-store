<?php $__env->startSection('content'); ?>


	<div class="m-grid__item m-grid__item--fluid m-wrapper">

		<div class="m-content">
			<div class="row">
				<div class="col-lg-12">
					<!--begin::Portlet-->
					<div class="m-portlet">
						<div class="m-portlet__head">
							<div class="m-portlet__head-caption">
								<div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
									<h3 class="m-portlet__head-text">
									Product Detail
									</h3>
								</div>
							</div>
						</div>
						<!--begin::Form-->
						<form class="m-form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/edit/'.$product->id)); ?>">
							<?php echo csrf_field(); ?>
							<div class="m-portlet__body">
								<div class="m-form__section m-form__section--first">
                                    <h3>
                                        Sku
                                    </h3>
									<div class="form-group m-form__group">
                                       <h4> <?php echo e($product->sku); ?></h4>
                                    <hr>
                                       <div>
                                        <img width="150px" height="150px" class="" src="<?php echo e(URL::asset('images/product/'.$product->image)); ?>">
                                    </div>

                                    


								</div>
							</div>
							<div class="m-portlet__foot m-portlet__foot--fit">
								<div class="m-form__actions m-form__actions">
									<a class="btn btn-primary float-xl-right" href="/products/index">
                                        back
                                </a>
								</div>
							</div>
						</form>
						<!--end::Form-->
					</div>
					<!--end::Portlet-->
					<!--begin::Portlet-->

					<!--end::Portlet-->
				</div>
				<div class="col-lg-6">
					<!--begin::Portlet-->

					<!--end::Portlet-->
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<!--begin::Portlet-->

					<!--begin::Portlet-->

					<!--end::Portlet-->
					<!--begin::Portlet-->

				</div>
			</div>
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\office\inventory_store\resources\views/product/show.blade.php ENDPATH**/ ?>