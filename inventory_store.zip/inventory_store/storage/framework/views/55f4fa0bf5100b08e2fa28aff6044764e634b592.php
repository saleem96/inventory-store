<?php $__env->startSection('scripts'); ?>

<script>
$.noConflict();
jQuery( document ).ready(function( $ ) {
    $('#myTable').DataTable();

});
 </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <!-- BEGIN: Subheader -->
        <div class="m-content">
            <div class="row">
                <div class="col-xl-12">
                    <div class="m-portlet">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">

                                    <span class="m-portlet__head-icon m--hide">
                                        <i class="la la-gear"></i>
                                    </span>

                                    <h3 class="m-portlet__head-text">
                                       Stock Page
                                    </h3>
                                </div>
                            </div>

                            <div class="m-portlet__head-tools">
                                <ul class="m-portlet__nav">
                                    <li class="m-portlet__nav-item">
                                        <div class="m-dropdown m-dropdown--inline m-dropdown--arrow m-dropdown--align-right m-dropdown--align-push"
                                             data-dropdown-toggle="hover" aria-expanded="true">
                                             <a href="/stocks/export"
                        
                         <button class="btn btn-primary float-xl-right" style="margin-top:15px;">Download to XLSX</button>
                     </a>
                     <a class="btn btn-primary" data-toggle="modal" data-target="#myDispatch" style="margin-left:40px;margin-top:15px;" href="">Upload sales XLSX</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                        </div>
                        <div class="modal fade" id="myDispatch">
                            <div class="modal-dialog" role="document" style="margin: 0 0 !important;left: 30% !important;">
                            <div class="modal-content">
                            <form action="<?php echo e(url('/stocks/import')); ?>" enctype="multipart/form-data" method="post">

                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                            Import XLSX
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">
                            ×
                            </span>
                            </button>
                            </div>
                            <div class="modal-body">
                            <div class="m-widget4">

                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" class="eq_status_id">
                            <div class="m-widget4">
                            <h2>Choose File</h2>

                            <div class="form-group m-form__group">
                                <label class="custom-file">
                                    <input type="file" id="file2" class="custom-file-input" data-preview="#preview" name="file">
                                    <span class="custom-file-control"></span>
                                </label>
                            </div>
                            </div>

                            </div>

                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Close
                            </button>

                            <button type="submit" class="btn btn-success">
                            Submit
                            </button>
                            </div>
                            </form>

                            </div>


                            </div>
                            </div>
                            </div>
                            </div>


                        <div class="m-portlet__body">
                            <!--begin::Section-->
                            <div class="m-section">
                                <div class="m-section__content">
                                    <div style="overflow:auto">
                                    <table class="table-responsive m-table m-table--head-bg-success" id=myTable>
                                        <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Image</th>
                                            <th>Sku</th>
                                            <th>Current Price</th>
                                            <th>Current Stock</th>
                                            <th>Daily-Avg(month)</th>
                                            <th>Daily-Avg(week)</th>
                                            <th>Day to OOS</th>
                                            <th>On the way</th>
                                            <th>Money on stock</th>
                                            <th>Total money on stock</th>


                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php  $i = 1  ?>
                                        <?php $__currentLoopData = $shipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <tr>

                                                <td><?php echo e($i); ?></td>
                                                <td>
                                            <?php if($ship->product): ?>
                                        <img width="50px" src="<?php echo e(asset('images/product/'.$ship->product->image)); ?>">
                                            <?php else: ?>
                                            <img width="50px" src="/images/no_image.png">

                                            <?php endif; ?></td>
                                                <td><?php echo e($ship->product->sku); ?></td>
                                                <td><?php echo e($ship->current_price); ?></td>
                                                <td><?php echo e($current_stock[$key]->current_stock); ?></td>


                                                <?php if(isset($month[$key]->quantity)): ?>

                                                      <td><?php echo e($month[$key]->quantity/30); ?></td>

                                                    <?php else: ?>
                                                    <td>No sales yet</td>
                                                <?php endif; ?>

                                                <?php if(isset($week[$key]->quantity)): ?>


                                                    <td><?php echo e($week[$key]->quantity/7); ?></td>


                                                    <?php else: ?>
                                                    <td>No sales yet</td>
                                                <?php endif; ?>
                                                <?php if(isset($current_stock[$key]->current_stock)&& isset($month[$key]->quantity)): ?>

                                                    <td><?php echo e(round( $current_stock[$key]->current_stock/$month[$key]->quantity)); ?></td>
                                                <?php else: ?>
                                                <td></td>
                                                <?php endif; ?>
                                                <?php if(isset($otw[$key]->quantity)): ?>

                                                    <td><?php echo e($otw[$key]->quantity); ?></td>

                                                <?php else: ?>
                                                <td></td>

                                                <?php endif; ?>
                                                <?php if(isset($money_s[$key]->total)): ?>

                                                    <td><?php echo e($money_s[$key]->total); ?></td>

                                                <?php else: ?>
                                                <td></td>
                                                <?php endif; ?>

                                                <?php if(isset($money_s[$key]->total)): ?>

                                                    <td><?php echo e($money_s[$key]->sum('total')); ?></td>

                                                <?php else: ?>
                                                <td></td>
                                                <?php endif; ?>

                                                <?php $i++ ?>


                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>

                                    </table>
                                    </div>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </div>

                            </div>
                            <!--end::Section-->
                        </div>

                        <!--end::Form-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\office\inventory_store\resources\views/stock/index.blade.php ENDPATH**/ ?>